﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace InterviewProj
{
    public static class Answers
    {
        public static int[] calculateFirstFiveFibonacci()
        {
            for (int i = 0; i < 20; i++)

            return default;
        }

        public static int squareRoot(int v)
        {
            return (int)Math.Sqrt((double)v);
            
        }

        public static bool isPrime(int v)
        {

            if (v <= 1)
                return false;
            if (v % 2 == 0)
                return false;

            for (int i=2; i <= v; i++)
            {
                if (v % i == 0)
                    return false;
            }

            return true;
        }

        public static bool isEven(int v)
        {
            if (v % 2 == 0)
                return true;

            return false;
        }

        public static int[] removeEveryOther(int[] v)
        {
            int n = 0;
            if (v.Length % 2 == 0)
                n = v.Length / 2;
            else
                n = ((v.Length + 1) / 2) - 1;

            int[] a = new int[n];
            bool bSkip = true;
            int nIndex = 0;
            foreach (int i in v)
            {
                if (!bSkip)
                {
                    a[nIndex++] = i;
                    bSkip = true;
                }
                else
                    bSkip = false;
                
            }
            return a;
        }

        public static char findFirstDuplicate(string v)
        {
            int i;
            foreach (char c in v)
            {
                i = v.IndexOf(c);
                i = v.IndexOf(c, i + 1, 2);
                if (i > -1)
                    return c;

            }
            return default;
        }

        public static (string name, int sum)[] aggregate((string name, int? val)[] vals)
        {
            return default;
        }

        public static int[] merge(int[] a, int[] b)
        {
            throw new NotImplementedException();
        }

        public static int findDistinctPairs(int[] vals, int addUpTo)
        {
            return default;
        }

        public class Rabbit { }
        public class Elephant { }

        public static string getAnimalSize(object animal)
        {
            return default;
        }

        public static List<string> fizzBuzzBlort() {
            return default;
        }

        public class EmployeeSalary 
        {
            public string FirstName {get; set;}
            public string LastName {get; set;}
            public int UID {get; set;}
            public int Year {get; set;}
            public Decimal? Salary {get; set;}
            public bool DuplicateFlag {get; set;} 
        }

        public static List<EmployeeSalary> getEmployeeSalariesForReport(List<EmployeeSalary> rawData) {
            return default;
        }
    }
}
