using System;
using System.Linq;
using Xunit;

namespace InterviewProj.Tests
{
    public class AnswersShould
    {
        [Fact]
        public void calculateFirstFiveFibonacci()
        {
            var res = Answers.calculateFirstFiveFibonacci();
            Assert.Equal(res, new[] { 1, 1, 2, 3, 5 });
        }

        [Fact]
        public void squareRoot()
        {
            Assert.Equal(2, Answers.squareRoot(4));
            Assert.Equal(4, Answers.squareRoot(16));
        }

        [Fact]
        public void isPrime()
        {
            Assert.True(Answers.isPrime(347));
            Assert.False(Answers.isPrime(348));
        }

        [Fact]
        public void isEven()
        {
            Assert.True(Answers.isEven(2));
            Assert.False(Answers.isEven(1));
        }

        [Fact]
        public void removeEveryOther()
        {
            Assert.Equal(new[] {1, 3, 5}, Answers.removeEveryOther(new[] { 1, 2, 3, 4, 5 }));
        }

        [Fact]
        public void findFirstDuplicate()
        {
            Assert.Equal('o', Answers.findFirstDuplicate("uhntethuoo"));
        }

        [Fact]
        public void aggregate()
        {
            var list = new[]
            {
                ("foo", 5),
                ("foo", 5),
                ("bar", 10),
                ("bar", (int?)null),
                ("bar", 10),
            };

            Assert.Equal(new[] { ("foo", 10), ("bar", 20) }, Answers.aggregate(list));
        }

        [Fact]
        public void merge()
        {
            /* do not include duplicates */
            var a = new[] { 1, 3, 8 };
            var b = new[] { 1, 6, 9, 12 };

            Assert.Equal(new[] { 1, 3, 6, 8, 9, 12 }, Answers.merge(a, b));
        }

        [Fact]
        public void findDistinctPairs()
        {
            /* find pairs of numbers that add up to 5, ex 1&4 but not 4&1 */
            Assert.Equal(2, Answers.findDistinctPairs(new[] { 1, 4, 2, 3 }, 5));
        }

        [Fact]
        public void getAnimalSize()
        {
            Assert.Equal("big", Answers.getAnimalSize(new Answers.Elephant()));
            Assert.Equal("small", Answers.getAnimalSize(new Answers.Rabbit()));
        }

        [Fact]
        public void fizzBuzzBlort()
        {
            // Not to be confused with FizzBuzz, which is completely different.
            // Return an list of strings for integers 1 - 100, where if the decimal representation
            // of the number contains a digit 3, substitute Fizz, if a 5, substitute Buzz, and if
            // a 7 substitute Blort.  If multiple substitutions would apply, concatenate them in the
            // same order the digits would appear.  If no substitutions apply, return the decimal
            // representation of the number itself.

            var expected = new [] {
                "1",
                "2",
                "Fizz",
                "4",
                "Buzz",
                "6",
                "Blort",
                "8",
                "9",
                "10",
                "11",
                "12",
                "Fizz",
                "14",
                "Buzz",
                "16",
                "Blort",
                "18",
                "19",
                "20",
                "21",
                "22",
                "Fizz",
                "24",
                "Buzz",
                "26",
                "Blort",
                "28",
                "29",
                "Fizz",
                "Fizz",
                "Fizz",
                "FizzFizz",
                "Fizz",
                "FizzBuzz",
                "Fizz",
                "FizzBlort",
                "Fizz",
                "Fizz",
                "40",
                "41",
                "42",
                "Fizz",
                "44",
                "Buzz",
                "46",
                "Blort",
                "48",
                "49",
                "Buzz",
                "Buzz",
                "Buzz",
                "BuzzFizz",
                "Buzz",
                "BuzzBuzz",
                "Buzz",
                "BuzzBlort",
                "Buzz",
                "Buzz",
                "60",
                "61",
                "62",
                "Fizz",
                "64",
                "Buzz",
                "66",
                "Blort",
                "68",
                "69",
                "Blort",
                "Blort",
                "Blort",
                "BlortFizz",
                "Blort",
                "BlortBuzz",
                "Blort",
                "BlortBlort",
                "Blort",
                "Blort",
                "80",
                "81",
                "82",
                "Fizz",
                "84",
                "Buzz",
                "86",
                "Blort",
                "88",
                "89",
                "90",
                "91",
                "92",
                "Fizz",
                "94",
                "Buzz",
                "96",
                "Blort",
                "98",
                "99",
                "100"
            };

            var results = Answers.fizzBuzzBlort();

            Assert.Equal(expected.Length, results.Count);
            for (int i = 0; i < results.Count; i++)
            {
                Assert.Equal(expected[i], results[i]);
            }
        }

        [Fact]
        public void getEmployeeSalariesForReport()
        {
            var rawData = new [] {
                new Answers.EmployeeSalary {
                    FirstName = "Foo",
                    LastName = "Bar",
                    UID = 1,
                    Year = 2017,
                    Salary = 70000
                },
                new Answers.EmployeeSalary {
                    FirstName = "Foo",
                    LastName = "Bar",
                    UID = 1,
                    Year = 2016,
                    Salary = 60000
                },
                new Answers.EmployeeSalary {
                    FirstName = "John",
                    LastName = "Smith",
                    UID = 2,
                    Year = 2016,
                    Salary = 75000
                },
                new Answers.EmployeeSalary {
                    FirstName = "Foo",
                    LastName = "Bar",
                    UID = 3,
                    Year = 2018,
                    Salary = 80000
                },
                new Answers.EmployeeSalary {
                    FirstName = "John",
                    LastName = "Smith",
                    UID = 2,
                    Year = 2015,
                    Salary = 65000
                },
                new Answers.EmployeeSalary {
                    FirstName = "John",
                    LastName = "Doe",
                    UID = 2,
                    Year = 2018,
                    Salary = 95000
                },
                new Answers.EmployeeSalary {
                    FirstName = "John",
                    LastName = "Doe",
                    UID = 2,
                    Year = 2017,
                    Salary = 85000
                },
            }.ToList();

            var result = Answers.getEmployeeSalariesForReport(rawData);

            // Employees with matching names but multiple distinct UIDs should be flaged as duplicates.
            Assert.All(result.Where(e => e.FirstName == "Foo" && e.LastName == "Bar"), e => Assert.True(e.DuplicateFlag));

            // Name changes don't matter.
            Assert.All(result.Where(e => e.UID == 2), e => Assert.False(e.DuplicateFlag));

            // Each UID should have one record for all covered years in the data set, records with null salary should
            // be inserted for missing years.
            var years = rawData.Select(d => d.Year).Distinct().ToArray();
            var uids = rawData.Select(d => d.UID).Distinct().ToArray();

            Assert.All(years, yr => Assert.All(uids, uid => Assert.Equal(1, result.Count(e => e.UID == uid && e.Year == yr))));

            // Records should be sorted ascending by UID then year.
            Assert.Null (       result[ 0].Salary);
            Assert.Equal(60000, result[ 1].Salary);
            Assert.Equal(70000, result[ 2].Salary);
            Assert.Null (       result[ 3].Salary);
            Assert.Equal(65000, result[ 4].Salary);
            Assert.Equal(75000, result[ 5].Salary);
            Assert.Equal(85000, result[ 6].Salary);
            Assert.Equal(95000, result[ 7].Salary);
            Assert.Null (       result[ 8].Salary);
            Assert.Null (       result[ 9].Salary);
            Assert.Null (       result[10].Salary);
            Assert.Equal(80000, result[11].Salary);
        }
    }
}
